import React from "react";
import "./App.css";
import SignUp from "./components/SignUp";
import ComponentName from "./components/Hero.jsx";
function App() {
  return (
    <>
      <ComponentName />
    </>
  );
}

export default App;
